# Studify

## NEW Implementations 
 - Updated AppRepository into 2 Branches:
	- AuthAppRepository: Anything related to User Authentication with Firebase
	- UserAppRepository: Anything related to User Profile Data
- Implemented Live Data Observers for Profile & Edit Profile
	- Allows users to dynamically change their profile pictures and usernames 
	- Set default picture when first creating account

