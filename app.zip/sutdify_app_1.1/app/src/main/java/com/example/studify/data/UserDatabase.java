package com.example.studify.data;

import androidx.room.RoomDatabase;


public abstract class UserDatabase extends RoomDatabase {
}
